Configurable Policy Engine Example
================================

This folder exposes a generic functional configurable policy engine configuration files
to provide to have a product following the nexus experience.

A vendor wishing to customize the behavior shall provides its own set of configuration files
within the device folder for the product to customize.

For any question about the parameter framework and configuration files,
See [the wiki on github](https://github.com/01org/parameter-framework/wiki).
